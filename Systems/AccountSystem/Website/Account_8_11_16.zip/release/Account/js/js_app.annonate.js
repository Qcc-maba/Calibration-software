
(function (angular) {
    'use strict';

    //////////////// AngularJS //////////////
    angular.module('module.accessories', []);

})(angular);
angular.module("module.admin",
    [
          "ui.router"
       
    ])
.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {

  

  

    $stateProvider
      .state('admin', {
          url: '/admin',
          views: {
              'root@': {
                  template: '<div class="adminMain" ui-view=""></div>',
                  controller: ['$scope', '$stateParams', '$state', function ($scope, $stateParams, $state) {
                      $("#splash-page").css("display", "none");
                      $("#navbar").css("display", "block");
                      $('.main-content').css("marginLeft", '0px');
                  }]
        
              }
           
          }
      })
    $stateProvider
      .state('admin.users', {
          url: '/users',
          template: '<div users></div>',
          controller: ['$scope', '$stateParams', '$state',
               function ($scope, $stateParams, $state) {
                  
                   $("#splash-page").css("display", "none");
               }]

     
      })
    $stateProvider
   .state('admin.user', {
       url: '/user/:email',
       template: '<div user></div>',
       controller: ['$scope', '$stateParams', '$state',
          function ($scope, $stateParams, $state) {

              $("#splash-page").css("display", "none");
          }]


    })
     //.state('admin.roles', {
     //    url: '/roles',
     //    template: '<div roles></div>',
     //    controller: ['$scope', '$stateParams', '$state',
     //          function ($scope, $stateParams, $state) {
                  
     //              $("#splash-page").css("display", "none");
     //          }]

     //})
     //  .state('admin.language', {
     //      url: '/language',
     //      template: '<div language></div>',
     //      controller: ['$scope', '$stateParams', '$state',
     //            function ($scope, $stateParams, $state) {

     //                $("#splash-page").css("display", "none");
     //            }]

     //  })
}]);


(function (angular) {
    'use strict';

    //////////////// AngularJS //////////////
    angular.module('module.httpProxies',[]);

})(angular);
(function (angular) {

    mi = angular
        .module('module.menuNavigation', []);
})(angular);






angular.module("module.profile",
    [
          "ui.router"

    ])
.config(['$stateProvider', '$urlRouterProvider', function ($stateProvider, $urlRouterProvider) {
    $stateProvider
      .state('profile', {
          url: '/profile',
          views: {
              'root@': {
                  template: '<div profile ui-view=""></div>',
                  controller: ['$scope', '$stateParams', '$state', function ($scope, $stateParams, $state) {
                      $("#splash-page").css("display", "none");
                      $('.main-content').css("marginLeft", '0px');
                  }]
              }

          }
      })
   
}]);

(function (angular) {
    mi = angular.module("module.widgets", []);
})(angular);

(function (angular) {
    'use strict';

    //////////////// AngularJS //////////////
    angular.module('module.accessories')
        .provider('directiveComm', directiveCommFactory);


    //////////////// JavaScript //////////////
    function directiveCommFactory() {

        function Connector() {

        }

        Connector.prototype.lastArguments_Up = null;
        Connector.prototype.lastArguments_Down = null;

        Connector.prototype.CallbackUp = function () {
            this.lastArguments_Up = arguments;

            if (this._CallbackUp) {
                return this._CallbackUp.apply(this, this.lastArguments_Up);
            }
        }
        Connector.prototype.CallbackDown = function () {

            this.lastArguments_Down = arguments;

            if (this._CallbackDown) {
                return this._CallbackDown.apply(this, this.lastArguments_Down);
            }

        }
        Connector.prototype.SetCallbackUp = function (callback) {
            this._CallbackUp = callback;

            if (this.lastArguments_Up) {
                return callback.apply(this, this.lastArguments_Up);
            }
        }
        Connector.prototype.SetCallbackDown = function (callback) {
            this._CallbackDown = callback;

            if (this.lastArguments_Down) {
                return callback.apply(this, this.lastArguments_Down);
            }
        }


        function _CreateConnector() {

            return new Connector();
        }


        return {
            $get: ['$http', 'baseProxy', function ($http, baseProxy) {



                //interface
                return {
                    CreateConnector: _CreateConnector
                };
            }]
        }
    }
})(angular);

(function (angular) {
    'use strict';

    angular.module('module.accessories')
      .directive('generalClick', generalClickFactory);

    /**********************************************************************************************************************************************************************/
    function generalClickFactory() {


        return {
            restrict: 'A',
            link: function (scope, element, attr) {

                //****************************closeMessage*********************************************
                function closeMessage(target) {
                    if (target.parents(".messageSidebar").length || target.hasClass("messageSidebar")) {

                    }
                    else if (target.parents(".openMessage").length) {
                        $('#body').css({ 'overflow-y': 'hidden' });

                        if ($('#page-sidebar').css("right") == "0px") {
                            $('#page-sidebar').css("right", "-500px");
                            //element.removeClass('open');
                        } else {
                            $('#page-sidebar').css("right", "0px");
                            //element.addClass('open');
                        }
                    }
                    else {
                        $('#page-sidebar').css("right", "-500px");
                        $('#users').attr("style", { right: "0px" });
                        if (target.parents('#ToggelApp').length >= 1) {
                            $('#body').css({ 'overflow-y': 'hidden' });
                        }
                        else if (target.parents('#main-navigation-menu').length >= 1 && target.parents('.sub-menu').length < 1) {
                            $('#body').css({ 'overflow-y': 'hidden' });
                        }

                        else {
                            $('#body').css({ 'overflow-y': 'auto' });
                        }

                    }
                }
                //*****************************scrollToDiv*****************************************************
                function scrollToDiv(target) {

                    if (target.parents("#previewList").length || target.parents("#previewMap").length || target.parents("#previewSquares").length) {
                        $('html,body').animate({
                            scrollTop: $("#siteDevicesPanel").offset().top
                        }, 'slow');
                    }
                    if (target[0].id == 'addDeviceGo') {
                        $('html,body').animate({
                            scrollTop: $("#addDeviceModalFooter").offset().top
                        }, 'slow');
                    }




                }
                //****************************closeMessage*********************************************
                function closeSmallMenue(target) {
                    if (target[0].id == 'openSmallMenue') {
                        $('#smallMenue').css({ 'display': "block" });
                    } else if (target.parents(".current-user").length || target.parents(".color").length) {
                        $('#smallMenue').css({ 'display': "block" });
                    }

                    else {
                        $('#smallMenue').css({ 'display': "none" });
                    }
                }

                //**********************************************************************************************

                $("body").click
                (
                  function (e) {
                      var target = $(e.target);
                      //closeMessage(target);
                      //scrollToDiv(target);
                      //closeSmallMenue(target);



                  }
                );

            }
        }

    }
})(angular);

(function (angular) {
    'use strict';
    //////////////// AngularJS //////////////
    angular.module('module.admin')
        .directive('user', userFactory);
    /***********************************************************************************************************************************************************/
    function userFactory() {
        return {
            restrict: 'EA',
            templateUrl: 'app/modules/module.admin/user.html',
            controller: ['$scope', 'adminProxy', '$stateParams', '$filter', '$state', function ($scope, adminProxy, $stateParams, $filter, $state) {

                $scope.ladda = {
                    delUser: false,
                    lock: false,
                    reset: false,
                    UIFormat: false,
                    setRoles:false
                }
                $scope.deleteConfirm = "";
                var email = $stateParams.email;
        

               

                $scope.setUIFormat = function (l) {
                    $scope.ladda.UIFormat = true;
                    $scope.currentUIFormat.uiFormatID = l.uiFormatID;
                    $scope.currentUIFormat.displayName = l.displayName;
                    adminProxy.setUIFormat(email,l.uiFormatID)
                        .success(function (data) {
                            $scope.ladda.UIFormat = false;
                            toastr.success($filter('translate')('successChanges'), $filter('translate')('Success'));
                        }).error(function (data, status, headers, config) {
                            toastr.error($filter('translate')('toastrErrMsgGet'), $filter('translate')('Error'));

                        });
                }

                $scope.currentUIFormat = {
                    uiFormatID: "",
                    displayName:""
                }
              
                $scope.resetPassordObj= {
                    "newPassword": "",
                    "confirmPassword": "",
                    "email": email
                }
                $scope.passwordFormValidation = false;

                $scope.resetPass = function (passwordForm) {
                    $scope.ladda.reset = true;
                    if (passwordForm) {
                        $scope.passwordFormValidation = false;
                        adminProxy.resetPass($scope.resetPassordObj)
                        .success(function (data) {
                    
                            $scope.resetPassordObj = {
                                "newPassword": "",
                                "confirmPassword": "",
                                "email": email
                            }
                            $scope.ladda.reset = false;
                            toastr.success($filter('translate')('successChanges'), $filter('translate')('Success'));
                        }).error(function (data, status, headers, config) {
                            toastr.error($filter('translate')('toastrErrMsgGet'), $filter('translate')('Error'));

                        });

                    } else {
                        $scope.passwordFormValidation = true;
                    }
                }
                $scope.lockUnLock = function (bool) {
                    $scope.ladda.lock = true;
                    adminProxy.lockUnLock(email, bool)
                        .success(function (data) {
                            $scope.user.userProfile.lockoutEnabled = bool;
                            toastr.success($filter('translate')('successChanges'), $filter('translate')('Success'));
                            $scope.ladda.lock = false;
                        }).error(function (data, status, headers, config) {
                            toastr.error($filter('translate')('toastrErrMsgGet'), $filter('translate')('Error'));
                  
                        });

                }
                $scope.delete = function () {
                    if ($scope.user.userProfile.email == $scope.deleteConfirm) {

                    
                        $scope.ladda.delUser = true;
                        adminProxy.delUser(email)
                             .success(function (data) {
                                 $scope.ladda.delUser = true;
                                 toastr.success($filter('translate')('successChanges'), $filter('translate')('Success'));
                                 $state.go('admin.users');
                                 $('#deleteUser').modal('hide');
                             }).error(function (data, status, headers, config) {
                                 toastr.error($filter('translate')('toastrErrMsgGet'), $filter('translate')('Error'));
                                 $('#deleteUser').modal('hide');
                             });
                    } else {

                    }

                }

                $scope.nevigateTo = function () {

                    var url = window.location.href;
                    var index = url.indexOf("/Account");
                    var prefix = url.substr(0, index)

                    window.location = prefix + '/?box=app';
                }
                var getUser = function (email) {

                    return adminProxy.getUser(email)
                        .success(function (data) {
                            $scope.user = data.body;
                            getUIFormats();
                            getUserRoles();
                      
                        })
                }
                var getUIFormats = function () {

                    return adminProxy.getUIFormats()
                        .success(function (data) {
                            $scope.LanguageList = data.body;
                            for (var i = 0; i < $scope.LanguageList.length; i++) {
                                $scope.LanguageList[i].imgURL = '../../../../Content/img/' + $scope.LanguageList[i].cultureCode + '.png';
                            }
                            for (var i = 0; i < data.body.length; i++) {
                               
                                if (data.body[i].uiFormatID == $scope.user.userProfile.uiFormatID) {
                                    $scope.currentUIFormat.uiFormatID = data.body[i].uiFormatID;
                                    $scope.currentUIFormat.displayName = data.body[i].displayName;
                                }
                            }
                        });
                }
                var getUserRoles = function () {

                    return adminProxy.getUserRoles(email)
                        .success(function (data) {
                            $scope.roles = data.body;
                        });
                }
                $scope.setUserRoles = function () {
                    $scope.ladda.setRoles = true;
                    return adminProxy.setUserRoles(email, $scope.roles)
                        .success(function (data) {
                     
                            toastr.success($filter('translate')('successChanges'), $filter('translate')('Success'));
                            $scope.ladda.setRoles = false;
                        }).error(function (data, status, headers, config) {
                            toastr.error($filter('translate')('toastrErrMsgGet'), $filter('translate')('Error'));

                        });
                }
               
                getUser(email);

            }],
            link: function (scope, element, attrs, ngModel) {
            }
        };
    }
})(angular);

(function (angular) {
    'use strict';
    //////////////// AngularJS //////////////
    angular.module('module.admin')
        .directive('users', usersFactory);
    /***********************************************************************************************************************************************************/
    function usersFactory() {
        return {
            restrict: 'EA',
            scope: {

            },
            templateUrl: 'app/modules/module.admin/users.html',
            controller: ['$scope', 'adminProxy', 'directiveComm', function ($scope, adminProxy, directiveComm) {
                var pageSize = 20;
                var currentPage = 1;
                $scope.search = "";
             
                $scope.paginationConector = directiveComm.CreateConnector();


                $scope.paginationConector.SetCallbackUp(function (pageNumber) {
                    getallUsers($scope.search, pageNumber, pageSize);
                });
                
               

                var getallUsers = function (search, pageNumber, pageSize) {
                    
                    return adminProxy.getallUsers(search, pageNumber, pageSize)
                        .success(function (data) {
                            currentPage = pageNumber;
                            $scope.pagerFlag = data.totalItems / pageSize > 1 ? true : false;
                            $scope.users = data.body;
                            $scope.paginationConector.CallbackDown(currentPage, pageSize, data.totalItems);
                            fixLoadingOff();
                        });
                }


                getallUsers($scope.search, currentPage, pageSize);



                $scope.nevigateTo = function () {

                    var url = window.location.href;
                    var index = url.indexOf("/Account");
                    var prefix = url.substr(0, index)

                    window.location = prefix + '/?box=app';
                }
                $scope.$watch('search', function (nVal, oVal) {
                    if (nVal !== oVal) {
                        fixLoadingOn();
                        currentPage = 1;
                        getallUsers(nVal, currentPage, pageSize);
                    }
                });
               
               
            }],
            link: function (scope, element, attrs, ngModel) {
                
            }

        };
    }

})(angular);








(function (angular) {
    'use strict';

    //////////////// AngularJS //////////////
    angular.module('module.httpProxies')
        .provider('baseProxy', baseProxy);


    //////////////// JavaScript //////////////

    function baseProxy() {

        var translateProvider;

        var _global = {
            data: {


                serverUri: ROOT_ADDR.SYSTEM_ACCOUNT_API,
             // serverUri: "http://10.0.0.108/WebServices/api",
             // serverUri: "http://bs.eitanr.com:10600/WebServices/api",   

                GoogleKey: "AIzaSyCKESGfcYKGe4QLnn4DESThvwE7xDEObnA"
            }
        };
        function buildPinLocation(lat, lan) {
            while(lan < -180) {
                lan=lan+360
            }
            while (lan > 180) {
                lan = lan - 360
            }
            return {
                latitude: lat,
                longitude: lan
            };
        }
       
        function timeConverter(UNIX_timestamp) {
            var a = new Date(UNIX_timestamp).toLocaleDateString();
          
            return a;
        }
        
       




        function buildLocation(lat, lan) {
            return {

                MapCenter: buildPinLocation(lat, lan),
                zoomLevel: 8,
                mode: "roadMap",
                autoBounds: true
            }

        };

        function saveManualMap(lat, lan, zoomLevel, mode, autoBounds) {
            return {

                MapCenter: buildPinLocation(lat, lan),
                zoomLevel: zoomLevel,
                mode: mode,
                autoBounds: autoBounds
            }

        };



        function convertToStringTime(time) {
            var hours = String(Math.floor(time / 3600));
            var min = String(Math.floor((time % 3600) / 60));
            if (hours.length == 1)
                hours = "0" + hours;
            if (min.length == 1)
                min = "0" + min;

            return hours + ":" + min;

        }

        function convertFromStringTime(time) {
            var d = new Date("1/1/2000 " + time);
          

            return d.getMinutes() * 60 + d.getHours() * 3600;

        }
        return {
            $get: ['$http', function ($http ) {


                //interface
                return {
                    Global: _global,
                    buildPinLocation: buildPinLocation,
                    buildLocation: buildLocation,
                    saveManualMap: saveManualMap,
                    timeConverter: timeConverter,
                    convertToStringTime: convertToStringTime,
                    convertFromStringTime: convertFromStringTime

                };
            }]
        }
    }
})(angular);






(function (angular) {

    menuController.$inject = ['$scope', '$location', '$http', 'adminProxy'];
    mi = angular
        .module('module.menuNavigation')
        .controller('menuController', menuController);

    function menuController($scope, $location, $http, adminProxy) {
        var runContainerHeight = function () {
            mainContainer = $('.main-content > .container');
            mainNavigation = $('.main-navigation');
            if ($pageArea < 760) {
                $pageArea = 760;
            }
            if (mainContainer.outerHeight() < mainNavigation.outerHeight() && mainNavigation.outerHeight() > $pageArea) {
                mainContainer.css('min-height', mainNavigation.outerHeight());
            } else {
                mainContainer.css('min-height', $pageArea);
            };
            if ($windowWidth < 768) {
                mainNavigation.css('min-height', $windowHeight - $('body > .navbar').outerHeight());
            }
            $("#page-sidebar .sidebar-wrapper").css('height', $windowHeight - $('body > .navbar').outerHeight()).scrollTop(0).perfectScrollbar('update');
        };

        $scope.toggleNavigationMenu = function (event) {

            var toggleIcon = $(event.target).parent();

            if (toggleIcon[0].localName == "li") {
                toggleIcon = $(event.currentTarget);
            }
            if ($(toggleIcon).parent().children('ul').hasClass('sub-menu') && ((!$('body').hasClass('navigation-small') || $windowWidth < 767) || !$(toggleIcon).parent().parent().hasClass('main-navigation-menu'))) {
                if (!$(toggleIcon).parent().hasClass('open')) {
                    $(toggleIcon).parent().addClass('open');
                    $(toggleIcon).parent().parent().children('li.open').not($(toggleIcon).parent()).not($('.main-navigation-menu > li.active')).removeClass('open').children('ul').slideUp(200);
                    $(toggleIcon).parent().children('ul').slideDown(200, function () {
                        runContainerHeight();
                    });
                } else {
                    if (!$(toggleIcon).parent().hasClass('active')) {
                        $(toggleIcon).parent().parent().children('li.open').not($('.main-navigation-menu > li.active')).removeClass('open').children('ul').slideUp(200, function () {
                            runContainerHeight();
                        });
                    } else {
                        $(toggleIcon).parent().parent().children('li.open').removeClass('open').children('ul').slideUp(200, function () {
                            runContainerHeight();
                        });
                    }
                }
            }
        }

        function delete_cookie(name) {
            document.cookie = name + '=; expires=Thu, 01 Jan 1970 00:00:01 GMT;';
        }
        $scope.toggleNavbar = function () {
            if (!$('body').hasClass('navigation-small')) {
                $('body').addClass('navigation-small');
                $('#main-navigation-menu').hide();

            } else {
                $('body').removeClass('navigation-small');
                $('#main-navigation-menu').show();
            };
        }

        $scope.logOut = function () {

            window.location = MAIN_LINKS.LOGIN.link;
            delete_cookie('AccessTokenAccount');
        }

    
        $scope.nevigateToHomePage = function () {
            window.location = MAIN_LINKS.ACCOUNT_APP_LIST.link;
        }
        function reloadUser() {
             adminProxy.loadCurrentProfile()

                .success(function (data) {
                    $scope.name = data.body;

                });
        };
        reloadUser();
        //************************************
        function getParameterByName(name, url) {
            if (!url) url = window.location.href;
            name = name.replace(/[\[\]]/g, "\\$&");
            var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
                results = regex.exec(url);
            if (!results) return null;
            if (!results[2]) return '';
            return decodeURIComponent(results[2].replace(/\+/g, " "));
        }
        
 








    }
})(angular);






(function (angular) {
    'use strict';
    //////////////// AngularJS //////////////
    angular.module('module.menuNavigation')
        .directive('menuDirective', menuDirectiveFactory);
    function menuDirectiveFactory() {





        var runToDoAction = function () {
            if ($(this).parents('.navbar-collapse')) {
                $(this).parents('.navbar-collapse').collapse('hide');;
            }
        };




        

        return {
            restrict: 'A',

            link: function (scope, element, attrs) {
              
                element.bind('click', runToDoAction);
            }
        };
    }
})(angular);







(function (angular) {
    'use strict';
    //////////////// AngularJS //////////////
    angular.module('module.profile')
        .directive('profile', profileFactory);



    function profileFactory() {
        return {
            restrict: 'EA',

            templateUrl: 'app/modules/module.profile/profile.html',

            controller: ['$scope', 'adminProxy', '$translate', 'tmhDynamicLocale', function ($scope, adminProxy, $translate, tmhDynamicLocale) {
                $scope.imgUrl = ROOT_ADDR.SYSTEM_ACCOUNT_API + "/Account/Profile/Image";
                $scope.validation = {
                    "profile": false,
                    "password": false,
                    "changePassword": false
                }
                $scope.changePasswordObject = {
                    "oldPassword": "",
                    "newPassword":"",
                    "confirmPassword":""
                }
                $scope.ladda = {
                 saveProfile:false,
                };
                var precent;
                var fill;
                //***********************************shortToFull**************************************************

                function shortToFull(short) {
                    switch (short) {
                        case "en":
                            return "English"
                            break;
                        case "es":
                            return  "Español"
                            break;
                        case "fr":
                            return "français"
                            break;

                    }
                    return "English"
                }
                //************************************************************GetCoockie*************************************************************
                function getCookie(cname) {
                    var name = cname + "=";
                    var ca = document.cookie.split(';');
                    for (var i = 0; i < ca.length; i++) {
                        var c = ca[i];
                        while (c.charAt(0) == ' ') c = c.substring(1);
                        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
                    }
                    return "";
                }
                //************************************************************setCookie*********************************
                function setCookie(cname, cvalue, exdays) {
                    var d = new Date();
                    d.setTime(d.getTime() + (exdays * 24 * 60 * 60 * 1000));
                    var expires = "expires=" + d.toUTCString();
                    document.cookie = cname + "=" + cvalue + "; path=/;" + expires;
                   // document.cookie = cookieName + "=" + cookieValue + ";domain=.example.com;path=/;expires=" + myDate;
                }
                //**************************************************************************************
                function getUsersKit() {

                    return adminProxy.getUsersKit()
                        .success(function (data) {
                            $scope.culture = data.body.uiFormats;
                            for (var i = 0; i < $scope.culture.length; i++) {
                                $scope.culture[i].imgURL = '../../../../Content/img/'+$scope.culture[i].cultureCode + '.png';
                            }
                            $scope.timeZone = data.body.timeZones;
                            $scope.temperatureUnit = data.body.temperatureUnits;
                            reloadUser();
                        });
                };
                //********************************************************************************
                $scope.chooseCulture = function(cl) {
                    $scope.ExtraDetails.culture = cl.displayName;
                    $scope.ExtraDetails.cultureCode = cl.cultureCode;
                    if (cl.cultureCode == 'He-Iljjjj') {
                    
                        $translate.use(cl.cultureCode);
                        tmhDynamicLocale.set(cl.cultureCode);
                    }else{
                     
                        $translate.use('en');
                        tmhDynamicLocale.set('en');
                      
                    }
                }
                //*********************************************************************************
                $scope.chooseTimeZone= function(tz) {
                    $scope.ExtraDetails.timeZone = "UTC - " + tz.gmtOffset / 60 + " " + tz.displayName;
                    $scope.ExtraDetails.zoneID = tz.zoneID;
                }
                //*********************************************************************************
                $scope.chooseTemperatureUnit = function (tu) {
                    $scope.ExtraDetails.temperatureUnit = tu.displayName;
                    $scope.ExtraDetails.typeUnitID = tu.typeUnitID;
                }
                //********************************************************************************
                function checkUserExtraDetails(userDetails) {
                    for (var i = 0; i < $scope.culture.length; i++) {
                        if ($scope.culture[i].cultureCode == userDetails.cultureCode) {
                            $scope.ExtraDetails.culture = $scope.culture[i].displayName;
                            $scope.ExtraDetails.cultureCode = $scope.culture[i].cultureCode;
                            break;
                        }
                    }
                    for (var i = 0; i < $scope.timeZone.length; i++) {
                        if ($scope.timeZone[i].zoneID == userDetails.timeZoneID) {
                            $scope.ExtraDetails.timeZone = "UTC " + $scope.timeZone[i].gmtOffset / 60 + " " + $scope.timeZone[i].displayName;
                            $scope.ExtraDetails.zoneID = $scope.timeZone[i].zoneID;
                            break;
                        }
                    }
                    for (var i = 0; i < $scope.temperatureUnit.length; i++) {
                        if ($scope.temperatureUnit[i].typeUnitID == userDetails.temperatureUnitID) {
                            $scope.ExtraDetails.temperatureUnit = $scope.temperatureUnit[i].displayName;
                            $scope.ExtraDetails.typeUnitID = $scope.temperatureUnit[i].typeUnitID;
                            break;
                        }
                    }
                }
                //*********************************************************************************************
                function reloadUser() {
                    return adminProxy.loadCurrentProfile()

                        .success(function (data) {
                            $scope.ExtraDetails = {};
                            $scope.userData = data.body;
                            checkUserExtraDetails($scope.userData);
                           

                        });
                };
                //********************************************setUserLanguage******************************
                $scope.setUserLanguage = function (short) {
                    $scope.selectedLenguage = shortToFull(short);
                    $scope.userData.cultureCode = short;
               
                }
                //****************************************************************
                $scope.saveUser = function (profileForm) {
                    if (profileForm) {
                        $scope.ladda.saveProfile = true;
                        $scope.validation.profile = false;
                        $scope.userData.timeZoneID = $scope.ExtraDetails.zoneID;
                        $scope.userData.temperatureUnitID = $scope.ExtraDetails.typeUnitID;
                        $scope.userData.cultureCode = $scope.ExtraDetails.cultureCode;
                        return adminProxy.SaveCurrentProfile($scope.userData)
                          .success(function (data, status, headers, config) {
                              //$translate.use($scope.data.cultureCode);
                              //tmhDynamicLocale.set($scope.data.cultureCode);
                              //setCookie("selectedLanguage", $scope.data.cultureCode, 30);
                              $scope.ladda.saveProfile = false;
                              toastr.success(' Details  Saved', 'Success!');
                         
                          }).error(function (data, status, headers, config) {
                              toastr.error('Details Not Saved', 'Error!');
                          });
                    } else {
                        $scope.validation.profile = true;
                    }
                }
                //***********************************************************
                $scope.changePassword = function (changePasswordForm) {
                    if (changePasswordForm) {
                        $scope.ladda.changePassword = true;
                        $scope.validation.changePassword = false;
                        return adminProxy.resetPassword($scope.changePasswordObject)
                          .success(function (data, status, headers, config) {
                              $scope.ladda.changePassword = false;
                              toastr.success(' Details  Saved', 'Success!');

                          }).error(function (data, status, headers, config) {
                              toastr.error('Details Not Saved', 'Error!');
                          });
                    } else {
                        $scope.validation.changePassword = true;
                    }
                }
                //**************************************************************
                $scope.myCallback = function (valueFromDirective) {
          
                    if (valueFromDirective.result) {

                        $scope.userData.imgURL = valueFromDirective.body;
                       
                        toastr.success('New Image  Saved', 'Success!');
                        resetLoading();
                        $scope.$apply();
                    } else {
                        toastr.error('Faild Upload Image', 'Error!');


                        resetLoading();
                        $scope.$apply();
                    }

                };

                //**********************************************************
                function resetLoading() {
                
                        $('.profileFixLoadingImage').css({ 'display': 'none' });
                        fill.width('0');
                        precent.html(0+ "%");
                       
                   
                }
                //*******************************************************************
                $scope.myANCallback = function (val) {

                    $('.profileFixLoadingImage').css({ 'display': 'block' });
                     precent = $('.loadingContainer .precent');
                     fill = $('.loadingContainer .loadingBar .fill');
                };
                //***************************************************************
                

                $scope.progress = function (val) {  // full width = 216px
                    precent.html(parseInt(val) + "%");
                    var currentWidth = parseInt ((val / 100) * 216);
                    fill.width(currentWidth);
                    $scope.$apply();
                    
                };
                //**************************************************
                getUsersKit();
              
               

            }],
            link: function (scope, element, attrs, ngModel) {
                $("#navbar").css("display", "none");


            }




        };

    }
})(angular);





angular.module('ngSimpleUpload', [])
    .directive('ngSimpleUpload', [function () {
        return {
            scope: {
                webApiUrl: '@',
                callbackFn: '=',
                callbackAn: '=',
                callbackProgress: '=',
                buttonId: '@'
            },
            link: function (scope, element, attrs) {
                function getCookie(cname) {
                    var name = cname + "=";
                    var ca = document.cookie.split(';');
                    for (var i = 0; i < ca.length; i++) {
                        var c = ca[i];
                        while (c.charAt(0) == ' ') c = c.substring(1);
                        if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
                    }
                    return "";
                }
                // if button id value exists
                if (scope.buttonId) {
                    $('#' + scope.buttonId).on('click', function () {
                        
                        // retrieves files from file input
                        var files = element[0].files;
                        // will not fire until file(s) are selected
                        if (files.length == 0) {
                            console.log('No files detected.');
                            return false;
                        }

                        Upload(files);
                    });
                }
                else {
                    // original code, trigger upload on change
                    element.on('change', function (evt) {

                   
                        scope.callbackAn(true);
                      
                   
                        
                        var files = evt.__files_ || (evt.target && evt.target.files);

                        Upload(files);
                        
                        // removes file(s) from input
                        $(this).val('');
                    });
                }





                //************************************

                function progress(e) {

                    if (e.lengthComputable) {
                        var max = e.total;
                        var current = e.loaded;

                        var Percentage = (current * 100) / max;
                        Percentage = parseInt(Percentage);
                        console.log(Percentage);


                        if (Percentage <= 99) {
                           scope.callbackProgress(Percentage);
                        }
                    }
                }
                //**

                function Upload(files) {
                    var fd = new FormData();
                    angular.forEach(files, function (v, k) {
                        fd.append('file', files[k]);
                    });

                    return $.ajax({
                        type: 'POST',
                        url: scope.webApiUrl,
                        headers: { 'Authorization': 'Bearer ' + getCookie('AccessTokenAccount') },
                        data: fd,
                        xhr: function () {
                            var myXhr = $.ajaxSettings.xhr();
                            if (myXhr.upload) {
                                myXhr.upload.addEventListener('progress', progress, false);
                            }
                            return myXhr;
                        },
                        async: true,
                        cache: false,
                        contentType: false,
                        processData: false
                    }).done(function (d) {
                        // callback function in the controller
                        scope.callbackFn(d);
                    }).fail(function (x) {
                        console.log(x);
                    });

                   
                }
            }
        }
    }]);
(function (angular) {
    'use strict';

    closeMainNevigationFactory.$inject = ['$log'];
    angular.module('module.widgets')
      .directive('closeMainNevigation', closeMainNevigationFactory);

    /**********************************************************************************************************************************************************************/
    function closeMainNevigationFactory($log) {

        return {
            restrict: 'A',
            link: function (scope, element, attr) {

                element.bind('click', function (e) {
                    if ($(e.target).parents('.navbar-collapse').length) {
                        element.removeClass("in");
                        element.attr("aria-expanded", false);
                    }
                })
            }
        }

    }
})(angular);
(function (angular) {
    'use strict';
    //////////////// AngularJS //////////////
    compareToFactory.$inject = ['$log'];
    angular.module('module.widgets')
        .directive('compareTo', compareToFactory);
    /********************************************************************************************************************************************************************/
    function compareToFactory($log) {

        return {
            require: "ngModel",
            scope: {
                otherModelValue: "=compareTo"
            },
            link: function (scope, element, attributes, ngModel) {

                ngModel.$validators.compareTo = function (modelValue) { //will run if someting change on confirm textfild
                    return modelValue == scope.otherModelValue; 
                };

                scope.$watch("otherModelValue", function () {
                    ngModel.$validate(); // run  ngModel.$validators.compareTo if somting change on password
                });
            }
        };
    }

    /*******************************************************************************************************************************************************************************/

})(angular);











(function (angular) {
    'use strict';

    //////////////// AngularJS //////////////
    angular.module('module.widgets')
        .directive('paging', paging);


    //////////////// JavaScript //////////////



    function paging() {

        return {

            restrict: 'EA',
            templateUrl: 'app/modules/module.widgits/paging/paging.html',
            scope: {
                comm: '='
            },
            controller: ['$scope', function ($scope) {

                $scope.menu = {
                 
                    'prev': false,
                    'forward': false
                
                }

                var totalPages = 0;
                var currentPage = 0;


                $scope.comm.SetCallbackDown(function (newPageNumber, pageSize, TotalItems) {

                    totalPages = Math.ceil(TotalItems / pageSize);
                    currentPage = newPageNumber;

                    firstLast();
                    $scope.list = build_list_of_pages();
                  
                });

                function changePage(page) {
                    firstLast();
                    if (0 < page && page <= totalPages) {

                        $scope.comm.CallbackUp(page);

                        return true;
                    }

                    return false;
                }

                function firstLast() {

                    if (currentPage == 1) {
                        $scope.menu.prev = true;
                       

                    }
                    else {
                        $scope.menu.prev = false;
                    }

                    if (currentPage >= totalPages) {
                        $scope.menu.forword = true;
                 

                    }
                    else {
                        $scope.menu.forword = false;
                    }
                }

                function build_list_of_pages() {
                    var listOfObjects = [];

                    if (totalPages < 5) {
                        for (var i = 1 ; i <= totalPages; i++) {

                            var singleObj = {}
                            singleObj['value'] = i;
                            if (i == currentPage) {
                                singleObj['type'] = 'active';
                            } else {
                                singleObj['type'] = '';
                            }

                            listOfObjects.push(singleObj);
                        }
                    }
                    else {
                        if (currentPage - 1 >= 0) {
                            if (currentPage - 1 >= 2) {   //two page before current page
                                var singleObj1 = {}
                                singleObj1['value'] = currentPage - 2;
                                singleObj1['type'] = '';
                                listOfObjects.push(singleObj1);

                                var singleObj2 = {}
                                singleObj2['value'] = currentPage - 1;
                                singleObj2['type'] = '';
                                listOfObjects.push(singleObj2);

                                var singleObj3 = {}
                                singleObj3['value'] = currentPage;
                                singleObj3['type'] = 'active';
                                listOfObjects.push(singleObj3);

                                if (currentPage + 1 <= totalPages) {
                                    var singleObj4 = {}
                                    singleObj4['value'] = currentPage + 1;
                                    singleObj4['type'] = '';
                                    listOfObjects.push(singleObj4);
                                }
                                if (currentPage + 2 <= totalPages) {
                                    var singleObj5 = {}
                                    singleObj5['value'] = currentPage + 2;
                                    singleObj5['type'] = '';
                                    listOfObjects.push(singleObj5);
                                }
                            }
                            if (currentPage - 1 == 1) {//one page before current page

                                var singleObj1 = {}
                                singleObj1['value'] = currentPage - 1;
                                singleObj1['type'] = '';
                                listOfObjects.push(singleObj1);

                                var singleObj2 = {}
                                singleObj2['value'] = currentPage;
                                singleObj2['type'] = 'active';
                                listOfObjects.push(singleObj2);

                                var singleObj3 = {}
                                singleObj3['value'] = currentPage + 1;
                                singleObj3['type'] = '';
                                listOfObjects.push(singleObj3);

                                var singleObj4 = {}
                                singleObj4['value'] = currentPage + 2;
                                singleObj4['type'] = '';
                                listOfObjects.push(singleObj4);

                                var singleObj5 = {}
                                singleObj5['value'] = currentPage + 3;
                                singleObj5['type'] = '';
                                listOfObjects.push(singleObj5);
                            }
                            if (currentPage - 1 == 0) {//no page before current page

                                var singleObj1 = {}
                                singleObj1['value'] = currentPage;
                                singleObj1['type'] = 'active';
                                listOfObjects.push(singleObj1);

                                var singleObj2 = {}
                                singleObj2['value'] = currentPage + 1;
                                singleObj2['type'] = '';
                                listOfObjects.push(singleObj2);

                                var singleObj3 = {}
                                singleObj3['value'] = currentPage + 2;
                                singleObj3['type'] = '';
                                listOfObjects.push(singleObj3);

                                var singleObj4 = {}
                                singleObj4['value'] = currentPage + 3;
                                singleObj4['type'] = '';
                                listOfObjects.push(singleObj4);

                                var singleObj5 = {}
                                singleObj5['value'] = currentPage + 4;
                                singleObj5['type'] = '';
                                listOfObjects.push(singleObj5);
                            }
                        }
                    }
                    return listOfObjects;
                }

                function prevPage() {

                    changePage(currentPage - 1);
                }

                function firstPage() {
                    changePage(1);
                }

                function lastPage() {

                    changePage(totalPages);
                }

                function forwardPage() {

                    changePage(currentPage + 1);

                }


                $scope.build_list_of_pages = build_list_of_pages;
                $scope.prevPage = prevPage;
                $scope.firstPage = firstPage;
                $scope.lastPage = lastPage;
                $scope.forwardPage = forwardPage;
                $scope.changePage = changePage;

            }]
        };
    
        
    }
})(angular);







(function (angular) {
    'use strict';

    //////////////// AngularJS //////////////
    angular.module('module.httpProxies')
        .provider('adminProxy', adminProxy);


    //////////////// JavaScript //////////////

    function adminProxy() {



        return {

            $get: ['$http', 'baseProxy', function ($http, baseProxy) {

                var data = baseProxy.Global.data.serverUri + '/Account/Profile';
                var timeZone = baseProxy.Global.data.serverUri + '/Types';
                ///////////////////////START DONE///////////////////////////////////////////////////////

                function _loadCurrentProfile() {
                    return $http.get(data);
                };

                function _getUsersKit() {
                    return $http.get(timeZone + "/All");
                };

                //function _getUserImage(userID) {
                //    return buildUri("GetUserImage/?UserID=" + (userID || 1), true);
                //};

                function _SaveCurrentProfile(userData) {
                    return $http.post(data, userData);
                };
                function _resetPassword(data) {
                    return $http.post(baseProxy.Global.data.serverUri + "/Account/ResetPassword", data);
                };

                //user administretion
                function _getallUsers(search, pageNumber, pageSize) {
                    return $http.get(baseProxy.Global.data.serverUri + "/Admin/Users?search="+search+"&pageNumber="+pageNumber+"&PageSize="+pageSize);
                };
                function _getUser(email) {
                    return $http.get(baseProxy.Global.data.serverUri + "/Admin/User?UserEmail=" + email);
                };
                function _getUIFormats() {
                    return $http.get(baseProxy.Global.data.serverUri + "/Types/UIFormats");
                };
                function _setUIFormat(email,id) {
                    return $http.post(baseProxy.Global.data.serverUri + "/Admin/User/UIFormat?UserEmail="+email+"&NewUIFormatID="+id);
                };
                function _resetPass(obj) {
                    return $http.post(baseProxy.Global.data.serverUri + "/Admin/User/Password",obj);
                };
                function _lockUnLock(email,bool) {
                    return $http.post(baseProxy.Global.data.serverUri + "/Admin/User/Lockout?UserEmail="+email+"&Lockout="+bool);
                };
                function _delUser(email) {
                    return $http.delete(baseProxy.Global.data.serverUri + "/Admin/User?UserEmail="+email);
                };
                function _getUserRoles(email) {
                    return $http.get(baseProxy.Global.data.serverUri + "/Admin/User/Roles?UserEmail="+email);
                };
                function _setUserRoles(email, obj) {
                    return $http.post(baseProxy.Global.data.serverUri + "/Admin/User/Roles?UserEmail=" + email, obj);
                };
                //interface
                return {
                    loadCurrentProfile: _loadCurrentProfile,
                    SaveCurrentProfile: _SaveCurrentProfile,
                    getUsersKit: _getUsersKit,
                    resetPassword: _resetPassword,
                    getallUsers: _getallUsers,
                    getUser: _getUser,
                    getUIFormats: _getUIFormats,
                    setUIFormat: _setUIFormat,
                    resetPass: _resetPass,
                    lockUnLock: _lockUnLock,
                    delUser: _delUser,
                    getUserRoles: _getUserRoles,
                    setUserRoles: _setUserRoles
                };
            }]
        }
    }
})(angular);
var LanguagePrefix = "../../Content/laguage/";
(function (angular) {
    var app = angular.module("mainApp",
        ["myApp.templates"
         , "ui.router"
         , "module.admin"
         , "module.profile"
         , "ngMessages"
         , "module.httpProxies"
         ,"module.accessories"
         , "module.menuNavigation"
         , "module.widgets"
         , "angular-ladda"
         , "pascalprecht.translate"
         , "tmh.dynamicLocale"
         , "ngSimpleUpload"
     ]);

    //***********************************************
    function getCookie(cname) {
        var name = cname + "=";
        var ca = document.cookie.split(';');
        for (var i = 0; i < ca.length; i++) {
            var c = ca[i];
            while (c.charAt(0) == ' ') c = c.substring(1);
            if (c.indexOf(name) == 0) return c.substring(name.length, c.length);
        }
        return "";
    }
    //************************************************
    app.factory('RequestService', function RequestService() {

        var AccessTokenAccount = getCookie('AccessTokenAccount');
        var request = function request(config) {
            if (config.url.indexOf(LanguagePrefix) >= 0) {
            }
            else {
                if (AccessTokenAccount) {
                    config.headers['Authorization'] = 'Bearer ' + AccessTokenAccount;
                    clearTimeWD();

                }
            }
            return config;
        }

        return {
            request: request
        }
    });
    
    
   
    app.config(
                ['$httpProvider','$translateProvider','tmhDynamicLocaleProvider',
    function ($httpProvider, $translateProvider, tmhDynamicLocaleProvider) {
           
            $httpProvider.interceptors.push('RequestService');
            //default language
            selectedLanguage = getCookie("selectedLanguage") || 'en';
            //fallback language if entry is not found in current language
            $translateProvider.fallbackLanguage('en');
            //load language entries from files
            $translateProvider.useStaticFilesLoader({
                prefix: '/Content/laguage/',
                suffix: '.txt' //file extension
            });
            $translateProvider.useSanitizeValueStrategy(null);

            tmhDynamicLocaleProvider.localeLocationPattern('/Content/laguage/angular-locale_{{locale}}.js')
        }
                ]
    )
    app.run(
                ['$rootScope', '$state', '$stateParams' , '$translate', 'tmhDynamicLocale',
        function ($rootScope, $state, $stateParams, $translate, tmhDynamicLocale) {
            
            $rootScope.$state = $state;
            $rootScope.$stateParams = $stateParams;
            $translate.use(selectedLanguage);
            tmhDynamicLocale.set(selectedLanguage);


            
        }
                ]
    )

})(angular);
