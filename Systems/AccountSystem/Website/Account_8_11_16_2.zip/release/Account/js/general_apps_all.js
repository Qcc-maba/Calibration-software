var accountToken = null;
var newToken = null;
var ROOT_ADDR = {

    SYSTEM_MF_ROOT: typeof (Custom_SYSTEM_MF_ROOT) != 'undefined' ? Custom_SYSTEM_MF_ROOT : "https://online.galcon-smart.com/",
    SYSTEM_ACCOUNT_API: typeof (Custom_SYSTEM_ACCOUNT__API) != 'undefined' ? Custom_SYSTEM_ACCOUNT__API : "/API"

};

var MAIN_LINKS = {
    PROFILE: { link: "#/profile" },
    LOGIN: { link: "../?box=login" },
    ACCOUNT_APP_LIST: { link: "?box=app" }
}

//////////////////////////////////////////////////////
//SYSTEM_ACCOUNT
var ACCOUNT_LOGIN_URI = {
    "systemName": "System_ACCOUNT_ADMIN",
    "BaseUrl":  "Account#/admin/users",
    "ImageSrc": "../../Content/img/user-management-.png",
    "Title": "Users Administration ",
    "SubTitle": "Users Administration System"
}
//SYSTEM_MF
var MF_ROOT_URI = {
    "systemName": "System_MF",
    "BaseUrl": ROOT_ADDR.SYSTEM_MF_ROOT,
    "ImageSrc": "../../Content/img/MF-CloudBased.png",
    "Title": "Cloud Based Control",
    "SubTitle": "Cyber-Rain UI"
}
//SYSTEM_XCI_ADMIN
var XCI_ADMIN = {
    "systemName": "System_XCI_ADMIN",
    "BaseUrl": ROOT_ADDR.SYSTEM_XCI_ADMIN_ROOT + "/index.html#/admin",
    "ImageSrc": "../../Content/img/XCI-Admin.png",
    "Title": "Cyber-Rain Admin",
    "SubTitle": "CR Administration System"
}
//SYSTEM_GSI_ADMIN
var GSI_ADMIN = {
    "systemName": "System_GSI_ADMIN",
    "BaseUrl": ROOT_ADDR.SYSTEM_ACCOUNT_ROOT + "/Gsi.html",
    "ImageSrc": "../../Content/img/GSI-Admin.png",
    "Title": "GSI Admin",
    "SubTitle": "GSI Administration System"
}

var SMALL_VIEW = 767;





var WD_Time = new Date().getTime();
var LastClickParam1="";
var LastClickParam2 = "";
var LastAction = "sssss";


function clearTimeWD() {
    WD_Time = new Date().getTime();
}

out = setInterval(function () {
    var now = new Date().getTime();
    var def = (now - WD_Time) / 60000   //min
    if (def >= 30) {
        clearInterval(out);
        if (window.location.href.indexOf("login") == -1) {
         //   window.location = MAIN_LINKS.LOGIN.link + "&returnUrl=" + encodeURIComponent(window.location.href);
        }
    }
}, 60000) //1 minutes interval

function setLastAction(action) {
    LastAction = action;
}
function fixLoadingOn() {
        document.getElementById("fixLoading").style.display = "block";
}
function fixLoadingOff() {
    document.getElementById("fixLoading").style.display = "none";
    
}

function closeNavbar() {
 
        $(".main-content").css("margin-left", "0px");
        $("#MyNavbar").hide();
        $("#dragbar").hide();
        $(".navbar-content").hide();
   
}

function openNavbar() {
    if (window.innerWidth > 768){
        $(".main-content").css("margin-left", "225px");
        $("#dragbar").show();
        $("#MyNavbar").show();
        $(".navbar-content").show();
}
}

